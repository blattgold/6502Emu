import numpy as np

def executeADCImm(cpu):
    def execute():
        cpu.fetchInstruction()
        oldAValue = cpu.getRegister("A")

        newAValue = np.uint8(cpu.currentInstruction + oldAValue + (1 if cpu.getFlag("carry") else 0))
        cpu.setFlag("carry", newAValue < oldAValue)
        cpu.setRegister("A", newAValue)

        cpu.addClockCyclesThisCycle(2)
    return execute

def executeADCZeroPage(cpu, memory):
    def execute():
        cpu.fetchInstruction()
        memValue = memory.getByte(cpu.currentInstruction)
        oldAValue = cpu.getRegister("A")

        newAValue = np.uint8(memValue + oldAValue + (1 if cpu.getFlag("carry") else 0))
        cpu.setFlag("carry", newAValue < oldAValue)
        cpu.setRegister("A", newAValue)

        cpu.addClockCyclesThisCycle(3)
    return execute


def LDSetFlags(result, cpu):
    if result == 0: cpu.setFlag("zero", True)
    else: cpu.setFlag("zero", False)
    if result & 0b10000000: cpu.setFlag("negative", True)
    else: cpu.setFlag("negative", False)

def Load2ByteAddress(cpu):
    cpu.fetchInstruction()
    addrLo = np.uint16(cpu.currentInstruction)
    cpu.fetchInstruction()
    addrHi = np.uint16(cpu.currentInstruction)
    return (addrHi << 8) | addrLo

def LoadAddressIndirectX(cpu, memory, indexReg):
    addr = LoadAddressAbsolute(cpu, memory)
    return addr

# LDA

def executeLDAImm(cpu):
    def execute():
        cpu.fetchInstruction()

        newAValue = cpu.currentInstruction
        cpu.setRegister("A", newAValue)

        LDSetFlags(newAValue, cpu)

        cpu.addClockCyclesThisCycle(2)
    return execute

def executeLDAZeroPage(cpu, memory):
    def execute():
        cpu.fetchInstruction()

        newAValue = memory.getByte(cpu.currentInstruction)
        cpu.setRegister("A", newAValue)

        LDSetFlags(newAValue, cpu)

        cpu.addClockCyclesThisCycle(3)
    return execute

def executeLDAZeroPageX(cpu, memory):
    def execute():
        cpu.fetchInstruction()
        memValue = memory.getByte(cpu.currentInstruction + cpu.getRegister("X"))

        newAValue = memValue
        cpu.setRegister("A", newAValue)

        LDSetFlags(newAValue, cpu)

        cpu.addClockCyclesThisCycle(4)
    return execute

def executeLDAAbsolute(cpu, memory):
    def execute():
        addr = Load2ByteAddress(cpu)
        memValue = memory.getByte(addr)

        newAValue = memValue
        cpu.setRegister("A", newAValue)

        LDSetFlags(newAValue, cpu)

        cpu.addClockCyclesThisCycle(4)
    return execute

def executeLDAAbsoluteIndexed(cpu, memory, offsetRegister):
    def execute():
        addr = Load2ByteAddress(cpu)
        addrPage = addr // 256
        addrOffsetX = addr + np.uint16(cpu.getRegister(offsetRegister))
        addrOffsetXPage = addrOffsetX // 256
        memValue = memory.getByte(addrOffsetX)

        newAValue = memValue
        cpu.setRegister("A", newAValue)

        LDSetFlags(newAValue, cpu)

        if addrOffsetXPage != addrPage: cpu.addClockCyclesThisCycle(1)
        cpu.addClockCyclesThisCycle(4)
    return execute

def executeLDAIndirectIndexed(cpu, memory, offsetRegister):
    def executeX():
        cpu.fetchInstruction()
        memValueAddrLo = np.uint16(memory.getByte(cpu.currentInstruction + np.uint16(cpu.getRegister("X"))))
        memValueAddrHi = np.uint16(memory.getByte(cpu.currentInstruction + np.uint16(cpu.getRegister("X") + 1)))
        memValueAddr = ((memValueAddrHi << 8) | memValueAddrLo)
        memValue = memory.getByte(memValueAddr)

        newAValue = memValue
        cpu.setRegister("A", newAValue)

        LDSetFlags(newAValue, cpu)

        cpu.addClockCyclesThisCycle(6)
    
    def executeY():
        cpu.fetchInstruction()
        memValueAddrLo = np.uint16(memory.getByte(cpu.currentInstruction))
        memValueAddrHi = np.uint16(memory.getByte(cpu.currentInstruction + 1))
        memValueAddr = (memValueAddrHi << 8) | memValueAddrLo
        memValueAddrPage = memValueAddr // 256
        memValueAddrOffsetY = memValueAddr + np.uint16(cpu.getRegister("Y"))
        memValueAddrOffsetYPage = memValueAddrOffsetY // 256
        memValue = memory.getByte(memValueAddrOffsetY)

        newAValue = memValue
        cpu.setRegister("A", newAValue)

        LDSetFlags(newAValue, cpu)

        if memValueAddrPage != memValueAddrOffsetYPage: cpu.addClockCyclesThisCycle(1)
        cpu.addClockCyclesThisCycle(5)
    return executeX if offsetRegister == "X" else executeY

# LDX

def executeLDXImm(cpu):
    def execute():
        cpu.fetchInstruction()
        newXValue = cpu.currentInstruction
        cpu.setRegister("X", newXValue)
        LDSetFlags(newXValue, cpu)
        cpu.addClockCyclesThisCycle(2)
    return execute

def executeLDXZeroPage(cpu, memory):
    def execute():
        cpu.fetchInstruction()
        memAddr = cpu.currentInstruction
        newXValue = memory.getByte(memAddr)

        cpu.setRegister("X", newXValue)
        LDSetFlags(newXValue, cpu)
        cpu.addClockCyclesThisCycle(3)
    return execute

def executeLDXZeroPageY(cpu, memory):
    def execute():
        cpu.fetchInstruction()
        memAddr = cpu.currentInstruction
        newXValue = memory.getByte(memAddr + cpu.getRegister("Y"))

        cpu.setRegister("X", newXValue)
        LDSetFlags(newXValue, cpu)
        cpu.addClockCyclesThisCycle(4)
    return execute

def executeLDXAbsolute(cpu, memory):
    def execute():
        memAddr = Load2ByteAddress(cpu)

        newXValue = memory.getByte(memAddr)

        cpu.setRegister("X", newXValue)
        LDSetFlags(newXValue, cpu)
        cpu.addClockCyclesThisCycle(4)
    return execute

def executeLDXAbsoluteY(cpu, memory):
    def execute():
        memAddr = Load2ByteAddress(cpu)
        memAddrOffsetY = memAddr + cpu.getRegister("Y")
        newXValue = memory.getByte(memAddrOffsetY)

        cpu.setRegister("X", newXValue)
        LDSetFlags(newXValue, cpu)

        memAddrPage = memAddr // 256
        memAddrOffsetYPage = memAddrOffsetY // 256
        if memAddrPage != memAddrOffsetYPage: cpu.addClockCyclesThisCycle(1)

        cpu.addClockCyclesThisCycle(4)
    return execute

# LDY

def executeLDYImm(cpu):
    def execute():
        cpu.fetchInstruction()
        newYValue = cpu.currentInstruction
        cpu.setRegister("Y", newYValue)
        LDSetFlags(newYValue, cpu)
        cpu.addClockCyclesThisCycle(2)
    return execute

def executeLDYZeroPage(cpu, memory):
    def execute():
        cpu.fetchInstruction()
        memAddr = cpu.currentInstruction
        newYValue = memory.getByte(memAddr)

        cpu.setRegister("Y", newYValue)
        LDSetFlags(newYValue, cpu)
        cpu.addClockCyclesThisCycle(3)
    return execute

def executeLDYZeroPageX(cpu, memory):
    def execute():
        cpu.fetchInstruction()
        memAddr = cpu.currentInstruction
        newYValue = memory.getByte(memAddr + cpu.getRegister("X"))

        cpu.setRegister("Y", newYValue)
        LDSetFlags(newYValue, cpu)
        cpu.addClockCyclesThisCycle(4)
    return execute

def executeLDYAbsolute(cpu, memory):
    def execute():
        memAddr = Load2ByteAddress(cpu)

        newYValue = memory.getByte(memAddr)

        cpu.setRegister("Y", newYValue)
        LDSetFlags(newYValue, cpu)
        cpu.addClockCyclesThisCycle(4)
    return execute

def executeLDYAbsoluteX(cpu, memory):
    def execute():
        memAddr = Load2ByteAddress(cpu)
        memAddrPage = memAddr // 256
        memAddrOffsetY = memAddr + cpu.getRegister("X")
        memAddrOffsetYPage = memAddrOffsetY // 256

        newYValue = memory.getByte(memAddrOffsetY)

        cpu.setRegister("Y", newYValue)
        LDSetFlags(newYValue, cpu)
        if memAddrPage != memAddrOffsetYPage: cpu.addClockCyclesThisCycle(1)
        cpu.addClockCyclesThisCycle(4)
    return execute